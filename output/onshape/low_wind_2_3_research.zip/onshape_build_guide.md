# Onshape build guide: Low Wind 2–3 m/s

This package is a CAD starting point for a classroom wind-turbine blade.

## Files

- `blade_geometry.csv` — station table: position, chord, twist, airfoil, and role.
- `airfoil_sections.csv` — airfoil metadata and Reynolds-number guidance.
- `blade_planform.dxf` — top-view blade outline in centimetres.
- `section_profiles/section_XX_*.dxf` — one ready-to-insert DXF per blade section.
- `section_profiles.dxf` — combined profile overview for reference.
- `design_metadata.json` — simulator metadata for this export.

## Suggested Onshape workflow

1. Create a new Onshape document and set the working unit to centimetres.
2. Import `blade_planform.dxf` as a sketch for the top-view blade shape.
3. On each section plane, insert the matching file from the `section_profiles/` folder.
4. The individual section DXFs are already scaled, centred, and pre-rotated by twist.
5. Loft through the section sketches, then add a hub connector that matches your
   real generator shaft.
6. Use a circular pattern for 3 blades.
7. Check the final rotor diameter is not greater than 1.00 m.

## Beginner hub

Do not create the hub sketch on a Mate connector. Create the hub sketch on a real
plane near the root, such as `S1 Root`, `Right`, `Front`, or `Top`.

Suggested starting dimensions:

- outside hub diameter: `8 cm` to `12 cm`;
- shaft hole diameter: measured shaft plus clearance;
- hub thickness: `2 cm` to `4 cm`;
- root overlap: `0.5 cm` to `2 cm`.

Sketch two concentric circles, then Extrude the ring. Use Boolean Union if the
hub and blade are separate parts.

## Three-blade pattern

Use Circular Pattern after one blade and the hub connection look correct.

```text
Pattern type: `Part pattern`
Quantity: `3`
Angle: `360 deg`
Axis: hub cylinder or shaft-hole circular edge
```

If the package shows an extra tip plane, remember that blue section planes are
references only. Pattern actual parts, not planes.

## Export STL

1. Right-click the final rotor part in the Parts list.
2. Choose Export.
3. Export format: `STL`.
4. Choose Binary STL unless your slicer requires ASCII.
5. Use millimetres if your slicer expects millimetres.
6. Open the STL in your slicer before printing.

## Important warning

This export is not a finished certified STL. It is a controlled geometry package
to help students rebuild the design in CAD, inspect it, and prepare a printable
model. Always verify wall thickness, root reinforcement, balance, and clearance
before testing in a wind tunnel.
