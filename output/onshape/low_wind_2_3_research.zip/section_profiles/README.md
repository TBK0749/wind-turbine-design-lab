# Individual section profile DXF files

Each DXF in this folder contains one airfoil profile only.
Profiles are scaled to the section chord in centimetres, centred around the
sketch origin, pre-rotated by the section twist angle, and simplified to
a loft-safe vertex count with printable trailing-edge thickness for Onshape.

Recommended Onshape workflow:

1. Create or select the matching section plane.
2. Start a new sketch on that plane.
3. Insert the matching DXF file from this folder.
4. Confirm the sketch.
5. Repeat from root to tip, then Loft through the section sketches.

| Section | File | Chord (cm) | Twist (deg) | Airfoil |
| --- | --- | ---: | ---: | --- |
| 1 (Root) | `section_01_root_NACA4418.dxf` | 12.5 | 18.4 | NACA 4418 |
| 2 | `section_02_NACA4418.dxf` | 11.6 | 14.6 | NACA 4418 |
| 3 | `section_03_SG6040.dxf` | 10.6 | 11.2 | SG6040 |
| 4 | `section_04_SG6043.dxf` | 9.5 | 7.9 | SG6043 |
| 5 | `section_05_SG6043.dxf` | 8.4 | 5.1 | SG6043 |
| 6 | `section_06_SG6043.dxf` | 7.3 | 2.9 | SG6043 |
| 7 | `section_07_SG6043.dxf` | 6.1 | 1.4 | SG6043 |
| 8 | `section_08_SG6043.dxf` | 4.8 | 0.3 | SG6043 |
| 9 (Tip) | `section_09_tip_SG6043.dxf` | 3.2 | 0.0 | SG6043 |

`section_profiles.dxf` in the package root is still included as an overview only.
